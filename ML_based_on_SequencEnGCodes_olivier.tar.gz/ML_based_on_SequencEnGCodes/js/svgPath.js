//https://codepen.io/alojzije/pen/ndfrI

//helper functions, it turned out chrome doesn't support Math.sgn() 
function signum(x) {
    return (x < 0) ? -1 : 1;
}
function absolute(x) {
    return (x < 0) ? -x : x;
}

function drawPath(svg, path, startX, startY, endX, endY) {
    // get the path's stroke width (if one wanted to be  really precize, one could use half the stroke size)
    var stroke =  parseFloat(path.css("stroke-width"));
    var arrowWidth = 10;

    // check if the svg is big enough to draw the path, if not, set heigh/width
    if (svg.attr("height") <  endY)                 svg.attr("height", endY + stroke + arrowWidth);
    if (svg.attr("width" ) < (startX + stroke) )    svg.attr("width", (startX + stroke + arrowWidth));
    if (svg.attr("width" ) < (endX   + stroke) )    svg.attr("width", (endX   + stroke + arrowWidth));
    
    var deltaX = (endX - startX) * 0.15;
    var deltaY = (endY - startY) * 0.15;


    // for further calculations which ever is the shortest distance
    var delta  =  deltaY < absolute(deltaX) ? deltaY : absolute(deltaX);

    
    // set sweep-flag (counter/clock-wise)
    // if start element is closer to the left edge,
    // draw the first arc counter-clockwise, and the second one clock-wise
    var arc1 = 0; var arc2 = 1;
    if (startX > endX) {
        arc1 = 1;
        arc2 = 0;
    }

    //two steps away
     if(endY - startY > 65){
         deltaY = deltaY * 2.5;
        delta = deltaY;

        path.attr("d",  "M"  + startX + " " + startY +
                    " V" + (startY + delta) +
                    " A" + delta + " " +  delta + " 0 0 " + arc1 + " " + (startX + delta*signum(deltaX)) + " " + (startY + 2*delta) +
                    " H" + (endX - delta*signum(deltaX)) + 
                    " A" + delta + " " +  delta + " 0 0 " + arc2 + " " + endX + " " + endY +
                    " V" + endY );
    }

    else{
         // draw tha pipe-like path
    // 1. move a bit down, 2. arch,  3. move a bit to the right, 4.arch, 5. move down to the end 6.draw arrow
    path.attr("d",  "M"  + startX + " " + startY +
                    " V" + (startY + delta) +
                    " A" + delta + " " +  delta + " 0 0 " + arc1 + " " + (startX + delta*signum(deltaX)) + " " + (startY + 2*delta) +
                    " H" + (endX - delta*signum(deltaX)) + 
                    " A" + delta + " " +  delta + " 0 0 " + arc2 + " " + endX + " " + (startY + 3*delta) +
                    " V" + endY +
                    " H" + (endX-arrowWidth) +
                    " L" + (endX + ","+ (endY+arrowWidth)) +
                    " L" + ((endX+arrowWidth) + "," + endY) +
                    " H" + endX);
    
    }


   
}

function connectElements(svg, path, startElem, endElem, layout) {
    var svgContainer= $(layout + " #svgContainer");

    // get (top, left) corner coordinates of the svg container   
    var svgTop  = svgContainer.offset().top;
    var svgLeft = svgContainer.offset().left;

    // get (top, left) coordinates for the two elements
    var startCoord = startElem.offset();
    var endCoord   = endElem.offset();

    if(typeof startCoord !== 'undefined' && typeof endCoord !== 'undefined'){

          // calculate path's start (x,y)  coords
        // we want the x coordinate to visually result in the element's mid point
        var startX = startCoord.left + 0.5*startElem.outerWidth() - svgLeft;    // x = left offset + 0.5*width - svg's left offset
        var startY = startCoord.top  + startElem.outerHeight() - svgTop;        // y = top offset + height - svg's top offset

            // calculate path's end (x,y) coords
        var endX = endCoord.left + 0.5*endElem.outerWidth() - svgLeft;
        var endY = endCoord.top  - svgTop;

        // call function for drawing the path
        drawPath(svg, path, startX, startY, endX, endY);

    }

  
}
function resetSVGsize(layout){
  $(layout+ " #svg-pipe").attr("height", "0");
  $(layout + "#svg-pipe").attr("width", "0"); 
}






